
<?php
$con = mysqli_connect("sql311.infinityfree.com","if0_36474363","HwGqtK3ckLu","if0_36474363_ministore");
if($con){
  echo("<script>alert('ok')</script>");
}
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>

<body>

</body>

</html>