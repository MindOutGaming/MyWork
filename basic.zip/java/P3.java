import java.util.Arrays; 

  

public class Main { 

    public static void main(String[] args) 

 {
        int arr[] = { 0, 1,0};
       
        	System.out.println("array:"+Arrays.toString(arr));
        
        	
        Arrays.sort(arr);
        
 System.out.println("Integer Array: "+ Arrays.toString(arr)); 

    } 
} 