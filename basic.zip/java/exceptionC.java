

public class Main {
	
	
	public static int ad(int a, int b){
	 	int c = a+b;
		return c;
		}
	public static void main(String[] args) {
	int x= ad(5,6);
	System.out.println(x);
	}
}